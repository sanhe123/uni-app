<?php
namespace hsC;
class index{
	
	public function index(){
		exit(jsonCode('ok', 'api 1.0.1...'));
	}
}
